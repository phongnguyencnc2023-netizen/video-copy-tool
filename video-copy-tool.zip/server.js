require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const { getTranscript } = require('./helpers/youtube');
const { analyzeWithOpenAI } = require('./helpers/openai');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json({ limit: '1mb' }));

app.post('/api/transcript', async (req, res) => {
  try {
    const { url, language } = req.body;
    if (!url) return res.status(400).send('Missing url');
    const transcript = await getTranscript(url, language || 'vi');
    return res.json({ transcript });
  } catch (err) {
    console.error(err);
    return res.status(500).send('Failed to fetch transcript: ' + String(err.message || err));
  }
});

app.post('/api/analyze', async (req, res) => {
  try {
    const { transcript, options } = req.body;
    if (!transcript) return res.status(400).send('Missing transcript');
    const result = await analyzeWithOpenAI(transcript, options || {});
    return res.json(result);
  } catch (err) {
    console.error(err);
    return res.status(500).send('Analyze failed: ' + String(err.message || err));
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
